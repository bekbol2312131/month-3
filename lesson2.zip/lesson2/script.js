// ---------------------------------------------------------дз

// let block = document.querySelector('.block')

// let position = 0
// let topPosition = 0
// let rightPosition = 0
// const moveBlock = () =>{
//     if(position <=300){
//         position += 16
//         block.style.left = `${position}px`
//         setTimeout(moveBlock,200)
//     }else if(position >=300 && topPosition <= 400){
//         topPosition += 16;
//         block.style.top = `${topPosition}px`
//         setTimeout(moveBlock,200)
//     }
// }
// moveBlock()
// const button = document.querySelector(".start")
// const button1 = document.querySelector(".stop")

// let num = 0
// ---------------------------------------------------------дз


// ---------------------------------------------------------дз
// button.addEventListener("click",() =>{
//     const timer = setInterval(() => {
//         num++
//         console.log(num)
//     },1000)
//     button1.addEventListener('click',() =>{
//         clearInterval(timer)
//     })
// })
// ---------------------------------------------------------дз



// ----------------------------------------- доп
// let arr = ['a','b','c','d','e','f']

// const uppercased = arr.map(arr => arr.toUpperCase());

// console.log(uppercased);
// -----------------------------------------доп

// ---------------------------------------------------------дз

// const getNum = (num) =>{
//     return function multiply(n) {
//         let i = n +num
//         console.log(i)
//     }
    
// } 

// const getTwo = getNum(4)
// getTwo(3)
// ---------------------------------------------------------дз
