let phoneNumber = document.querySelector(".phoneNumber")
let button = document.querySelector('.phoneSubmit')
let result = document.querySelector('#result')
console.log(phoneNumber)

let regExp = /^\+996 \d{3} \d{2}-\d{2}-\d{2}$/

button.addEventListener("click", () => {
    if(regExp.test(phoneNumber.value)){
        result.innerText = "success"
        result.style.color = "green"
    }else{
        result.innerText = "wrong number"
        result.style.color = "red"
    }
})

let idNumber = document.querySelector(".idNumber")
let button2 = document.querySelector(".idSubmit")
let result2 = document.querySelector("#result2")

let regexp = /1/

button2.addEventListener("click", () => {
    if(regexp.test(idNumber.value)){
        result2.innerText = "success"
        result2.style.color = "green"
    }else{
        result2.innerText = "wrong ID"
        result2.style.color = "red"
    }
})


let arr = [1,12,15,22,8,25];

for (let i = 0; i < arr.length; i++)
{
  if ((arr[i] % 2) === 0)
  {
  	console.log(arr[i]);
  }
}

